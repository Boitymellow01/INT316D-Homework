/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author TDK Nkadiey
 */
public class UpdateDoCStatus extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
            int appointmentId = Integer.parseInt(request.getParameter("appointmentId"));
            String docname= request.getParameter("doctorId");
            String timeSlot = request.getParameter("timeSlot");
            
        try {
            // Call a DAO method to update the appointment
            boolean updated = new DatabaseManager().updateAppointmentDoctorAndTime(appointmentId, docname, timeSlot);
            
            
            if (updated) {
                // Redirect or forward to success page or refresh
                 RequestDispatcher dispatcher = request.getRequestDispatcher("AdminVieAppointments.do");
                dispatcher.forward(request, response);
            } else {
                // Handle update failure
                request.setAttribute("error", "Failed to assign doctor and time slot.");
                request.getRequestDispatcher("appointments.jsp").forward(request, response);
            }

            
        } catch (SQLException ex) {
            Logger.getLogger(UpdateDoCStatus.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UpdateDoCStatus.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
