package Controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class deleteMedication extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");

        try {
            int id = Integer.parseInt(idParam);
            new DatabaseManager().deleteMedicationById(id);

            // Set success message in session
            HttpSession session = request.getSession();
            session.setAttribute("message", "Medication deleted successfully.");

            
            RequestDispatcher dispatcher = request.getRequestDispatcher("viewAllMedications.do");
                dispatcher.forward(request, response);
            //response.sendRedirect("viewAllMedications.do");

        } catch (NumberFormatException | SQLException | ClassNotFoundException e) {
            Logger.getLogger(deleteMedication.class.getName()).log(Level.SEVERE, null, e);

            // Set error message in session
            request.getSession().setAttribute("message", "Error: Medication could not be deleted.");
            response.sendRedirect("viewAllMedications.do");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirect to view page instead of throwing error
        response.sendRedirect("viewAllMedications.do");
    }
}
