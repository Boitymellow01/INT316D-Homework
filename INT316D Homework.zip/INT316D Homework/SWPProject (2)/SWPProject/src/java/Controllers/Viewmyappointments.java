package Controllers;

import Model.Appointment;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Viewmyappointments extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Retrieve patient ID from session
        HttpSession session = request.getSession();
        Integer patientId = (Integer) session.getAttribute("patientId");

        try {
            // 2. Get appointments from the database
            List<Appointment> appointments = new DatabaseManager().getAppointmentsByPatientId(patientId);

            // 3. Set the appointments attribute to be used in the JSP
            request.setAttribute("appointments", appointments);

            // 4. Forward the request to the JSP page
            request.getRequestDispatcher("viewappointments.jsp").forward(request, response);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Viewmyappointments.class.getName()).log(Level.SEVERE, null, ex);
            // You could add error handling here (e.g., forward to an error page)
        }
    }
}
