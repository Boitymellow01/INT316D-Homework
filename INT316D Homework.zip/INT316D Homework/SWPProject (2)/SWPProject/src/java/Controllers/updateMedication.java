package Controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class updateMedication extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            
            new DatabaseManager().updateMedicationQuantity(id, quantity);

            request.getSession().setAttribute("message", "Medication updated successfully!");
           // response.sendRedirect("viewAllMedications.do");
            
             RequestDispatcher dispatcher = request.getRequestDispatcher("viewAllMedications.do");
                dispatcher.forward(request, response);

        } catch (NumberFormatException e) {
            Logger.getLogger(updateMedication.class.getName()).log(Level.SEVERE, "Invalid input", e);
            request.getSession().setAttribute("message", "Invalid input provided.");
            response.sendRedirect("viewAllMedications.do");
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(updateMedication.class.getName()).log(Level.SEVERE, null, ex);
            request.getSession().setAttribute("message", "An error occurred while updating medication.");
            response.sendRedirect("viewAllMedications.do");
        }
    }
}
