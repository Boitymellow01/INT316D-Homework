package Controllers;

import Controllers.DatabaseManager;
import Model.Appointment;
import java.sql.Connection;


import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/DoctorReportServlet")
public class DoctorReportServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the doctor's name from session or request
        HttpSession session = request.getSession(false);
        String doctorName = (String) session.getAttribute("doctorname");

        if (doctorName != null) {
            try {
                // Call the method to get appointments
                DatabaseManager dbManager = new DatabaseManager();
                List<Appointment> appointments = dbManager.getAppointmentsByDoctor(doctorName);

                // Set appointments list to request attribute
                request.setAttribute("appointments", appointments);

                // Forward to the JSP page for displaying the report
                RequestDispatcher dispatcher = request.getRequestDispatcher("doctorreport.jsp");
                dispatcher.forward(request, response);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database connection failed");
            }
        } else {
            response.sendRedirect("login.jsp"); // Redirect if no session
        }
    }

   
}
