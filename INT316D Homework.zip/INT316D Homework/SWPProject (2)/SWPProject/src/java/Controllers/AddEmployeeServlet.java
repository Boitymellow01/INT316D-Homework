/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author TDK Nkadiey
 */
public class AddEmployeeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Get form parameters
        Integer employeeid = Integer.parseInt(request.getParameter("employeeid"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String role = request.getParameter("role");
        String department = request.getParameter("department");
        
        try {
            boolean isAdded = new DatabaseManager().addEmployee(employeeid, name, email, role,department);
            if(isAdded){
            RequestDispatcher disp = request.getRequestDispatcher("addedemployee.jsp");
            disp.forward(request, response);
            }else {
            RequestDispatcher disp = request.getRequestDispatcher("employeeAddedFailure.jsp");
            disp.forward(request, response);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AddEmployeeServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(AddEmployeeServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    

}
