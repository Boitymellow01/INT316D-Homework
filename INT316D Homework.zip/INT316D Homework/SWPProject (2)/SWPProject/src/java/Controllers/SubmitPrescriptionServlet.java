/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Model.Prescription;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author TDK Nkadiey
 */
public class SubmitPrescriptionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      int appointmentId = Integer.parseInt(request.getParameter("appointmentId"));
        String prescriptionText = request.getParameter("prescription");
  
        HttpSession session = request.getSession();
        String doctorName = (String) session.getAttribute("doctorname");
        
        int patientid = Integer.parseInt(request.getParameter("patientId"));
        
        Prescription prescription = new Prescription(appointmentId, doctorName, patientid, prescriptionText);
        
         boolean success = new DatabaseManager().savePrescription(prescription);
         
          if (success) {
            response.sendRedirect("DoctorDashboard.jsp?msg=Prescription+submitted");
        } else {
            response.sendRedirect("DoctorDashboard.jsp?error=Failed+to+submit+prescription");
        }
    }


}
