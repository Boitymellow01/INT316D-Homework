package Controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet to handle adding medication
 * Author: TDK Nkadiey
 */
public class AddMeds extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve form data
        String productName = request.getParameter("productName");
        String productType = request.getParameter("productType");
        int stockQuantity = Integer.parseInt(request.getParameter("stockQuantity"));

        try {
            boolean isProductAdded = new DatabaseManager().addProduct(productName, productType, stockQuantity);

            if (isProductAdded) {
                // Success modal
                response.getWriter().println(getModalHTML(
                    "Success",
                    "Product <strong>" + productName + "</strong> has been added successfully.",
                    "admindashboard.jsp"
                ));
            } else {
                // Failure modal
                response.getWriter().println(getModalHTML(
                    "Failed",
                    "Product may already exist. Please update the quantity instead.",
                    "admindashboard.jsp"
                ));
            }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AddMeds.class.getName()).log(Level.SEVERE, null, ex);
            response.getWriter().println(getModalHTML(
                "Error",
                "An unexpected error occurred while adding the product.",
                "admindashboard.jsp"
            ));
        }
    }

    /**
     * Returns HTML for a modal dialog with a message and redirect behavior.
     */
    private String getModalHTML(String title, String message, String redirectUrl) {
        return "<!DOCTYPE html>"
                + "<html><head><meta charset='UTF-8'><title>" + title + "</title>"
                + "<style>"
                + "body { margin: 0; font-family: 'Segoe UI', sans-serif; background-color: rgba(0,0,0,0.1); }"
                + ".modal { display: flex; justify-content: center; align-items: center; height: 100vh; background: rgba(0,0,0,0.5); }"
                + ".modal-content { background: #fff; padding: 30px; border-radius: 10px; width: 350px; text-align: center; box-shadow: 0 0 10px rgba(0,0,0,0.2); }"
                + ".modal-content h2 { margin-bottom: 15px; color: #004080; }"
                + ".modal-content p { margin-bottom: 25px; color: #333; }"
                + ".modal-content button { background-color: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; }"
                + ".modal-content button:hover { background-color: #0056b3; }"
                + "</style></head><body>"
                + "<div class='modal'>"
                + "<div class='modal-content'>"
                + "<h2>" + title + "</h2>"
                + "<p>" + message + "</p>"
                + "<button onclick='window.location.href=\"" + redirectUrl + "\"'>OK</button>"
                + "</div></div>"
                + "</body></html>";
    }
}
