package Controllers;

import Model.Appointment;
import Model.Doctor;
import Model.Employee;
import Model.Patient;
import Model.Prescription;
import Model.ReportStats;
import Model.Sehlare;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DatabaseManager {

    static List<Appointment> getAllAppointments;

    public static List<Appointment> getAllAppointments() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Method to register a patient
    public boolean registerPatients(int patiendid, String firstName, String lastName, String email,
            String password, String gender,
            String dob, String address, String phone) throws ClassNotFoundException, SQLException {
        // SQL query to insert data into the patient table
        String sql = "INSERT INTO patient (patiendid, firstname, lastname, email, password, gender, dob, address, creationdate, phonenumber) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)";

        // Initialize connection and PreparedStatement
        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the PreparedStatement
            statement.setInt(1, patiendid);
            statement.setString(2, firstName); // first name
            statement.setString(3, lastName);  // last name
            statement.setString(4, email);     // email
            statement.setString(5, password);  // password
            statement.setString(6, gender);    // gender
            statement.setString(7, dob);       // date of birth (make sure format is correct)
            statement.setString(8, address);   // address
            statement.setString(9, phone);     // phone number

            // Execute the insert query
            int rowsAffected = statement.executeUpdate();

            // Return true if the patient was successfully inserted
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();  // Print the exception stack trace if an error occurs
            return false; // Return false if there was an error
        }
    }
    
    
public boolean updateAppointmentDoctorAndTime(int appointmentId, String docname, String timeSlot) throws SQLException, ClassNotFoundException {
    String sql = "UPDATE appointment SET doctorname = ?, time_slot = ? WHERE appointmentid = ?";
    try (Connection conn = new DatabaseConnection().getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, docname);
        stmt.setString(2, timeSlot);
        stmt.setInt(3, appointmentId);

        return stmt.executeUpdate() > 0;
    }
}

    //Handle login
    // Method to retrieve password for a given email
    public String logimMethod(String email) throws ClassNotFoundException, SQLException {
        String password = null;

        // SQL query to fetch the password for the given email
        String sql = "SELECT password FROM patient WHERE email = ?";

        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set the email parameter for the query
            statement.setString(1, email);

            // Execute the query and get the result set
            ResultSet resultSet = statement.executeQuery();

            // If the user exists, retrieve the password
            if (resultSet.next()) {
                password = resultSet.getString("password");
            }
        }

        // Return the password (could be null if no user is found)
        return password;
    }

    // Method to add a product (medication) to the database
    public boolean addProduct(String productName, String productType, int stockQuantity) throws ClassNotFoundException, SQLException {
        // SQL query to insert product data into the product table
        String sql = "INSERT INTO product (name, type, quantity, creation) "
                + "VALUES (?, ?, ?, CURRENT_TIMESTAMP )";

        // Initialize connection and PreparedStatement
        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the PreparedStatement
            statement.setString(1, productName);
            statement.setString(2, productType);
            statement.setInt(3, stockQuantity);

            // Execute the insert query
            int rowsAffected = statement.executeUpdate();

            // Return true if the product was successfully inserted
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();  // Print the exception stack trace if an error occurs
            return false; // Return false if there was an error
        }
    }

    public boolean addAppointment(int patientId, String appointmentDate, String department, String description, String status, String doctorname, String time)
        throws ClassNotFoundException, SQLException {

    // SQL query to insert an appointment into the appointments table
    String sql = "INSERT INTO appointment (patientid, date, department, description, status, doctorname, time_slot, creation) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

    // Use try-with-resources for auto-closing
    try (Connection connection = new DatabaseConnection().getConnection();
         PreparedStatement statement = connection.prepareStatement(sql)) {

        // Set parameters for the PreparedStatement
        statement.setInt(1, patientId);
        statement.setString(2, appointmentDate); // Make sure date is in YYYY-MM-DD format
        statement.setString(3, department);
        statement.setString(4, description);
        statement.setString(5, status);
        statement.setString(6, doctorname);
        statement.setString(7, time);  // Set time at index 7

        // Execute the insert query
        int rowsAffected = statement.executeUpdate();

        // Return true if the insert was successful
        return rowsAffected > 0;

    } catch (SQLException e) {
        e.printStackTrace();  // Print error for debugging
        return false;          // Return false if any error occurred
    }
}

// Method to get patient ID by email
    public int getPatientIdByEmail(String email) throws ClassNotFoundException, SQLException {
        int patientId = -1; // Default value if not found

        String sql = "SELECT patiendid FROM patient WHERE email = ?";

        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, email);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                patientId = resultSet.getInt("patiendid");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return patientId;
    }

    public List<Appointment> getAppointmentsByPatientId(int patientId) throws ClassNotFoundException, SQLException {
        List<Appointment> appointments = new ArrayList<>();

        String sql = "SELECT * FROM appointment WHERE patientid = ? ORDER BY creation DESC";

        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, patientId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Appointment appt = new Appointment();
                //appt.setId(resultSet.getInt("id"));
                appt.setPatientId(resultSet.getInt("patientid"));
                appt.setAppointmentDate(resultSet.getDate("date").toString());
                appt.setDepartment(resultSet.getString("department"));
                appt.setCreationDate(resultSet.getTimestamp("creation").toString());
                appt.setDescription(resultSet.getString("description"));
                appt.setDoctorname(resultSet.getString("doctorname"));
                appt.setStatus(resultSet.getString("status"));
                appointments.add(appt);
            }
        }

        return appointments;
    }
//Update worker email 

    public boolean updateEmployeeEmail(int employeeId, String newEmail) {
        try (Connection conn = new DatabaseConnection().getConnection();
                PreparedStatement stmt = conn.prepareStatement("UPDATE employee SET email = ? WHERE employeeid = ?")) {

            stmt.setString(1, newEmail);
            stmt.setInt(2, employeeId);

            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public Employee getDoctorByEmail(String emailInput) {
    Employee doctor = null;

    try (Connection conn = new DatabaseConnection().getConnection()) {
        String sql = "SELECT name,email, password, role FROM employee WHERE email = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, emailInput);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            doctor = new Employee();
            doctor.setEmail(rs.getString("email"));
            doctor.setPassword(rs.getString("password"));
            doctor.setRole(rs.getString("role"));
             doctor.setName(rs.getString("name"));
        }

        rs.close();
        ps.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return doctor;
}


    //Delete employee
    public boolean deleteEmployeeById(int employeeId) {
        boolean success = false;
        try {
            Connection conn = new DatabaseConnection().getConnection();
            String sql = "DELETE FROM employee WHERE employeeid = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, employeeId);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return success;
    }

    //Method to retrieve all the workers 
    public List<Employee> retrieveAllWorkers() throws ClassNotFoundException, SQLException {
        List<Employee> empleoyees = new ArrayList<>();

        String sql = "SELECT * FROM employee";

        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {

                Employee emp = new Employee();

                emp.setCreation(resultSet.getTimestamp("creation"));
                emp.setEmail(resultSet.getString("email"));
                emp.setName(resultSet.getString("name"));
                emp.setEmployeeid(resultSet.getInt("employeeid"));
                emp.setRole(resultSet.getString("role"));

                empleoyees.add(emp);

            }
        }

        return empleoyees;
    }

    // Method to add a new employee
    public boolean addEmployee(int employeeId, String name, String email, String role,String department) throws ClassNotFoundException, SQLException {
        // SQL query to insert an employee into the employee table
        String sql = "INSERT INTO employee (employeeid, name, email, creation, role,department) VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?,?)";

        // Use try-with-resources for auto-closing
        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the PreparedStatement
            statement.setInt(1, employeeId);
            statement.setString(2, name);
            statement.setString(3, email);
            statement.setString(4, role);
            statement.setString(5, department);
            // Execute the insert query
            int rowsAffected = statement.executeUpdate();

            // Return true if the insert was successful
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();  // Print error for debugging
            return false;         // Return false if any error occurred
        }
    }

    // Method to update the password in the database
    public boolean updatePassword(int employeeId, String email, String newPassword) throws SQLException, ClassNotFoundException {
        // SQL query to update the password
        String sql = "UPDATE employee SET  password = ? WHERE email = ? AND employeeid = ?";

        // Use try-with-resources to handle database connection and statement
        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set parameters for the PreparedStatement
            statement.setString(1, newPassword);
            statement.setString(2, email);
            statement.setInt(3, employeeId);

            // Execute the update query
            int rowsAffected = statement.executeUpdate();

            // If the update was successful, return true
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if there was an error
        }
    }

    //Handle login
    // Method to retrieve password for a given email
    public String logimDoctorMethod(String email) throws ClassNotFoundException, SQLException {
        String password = null;

        // SQL query to fetch the password for the given email
        String sql = "SELECT password FROM employee WHERE email = ?";

        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            // Set the email parameter for the query
            statement.setString(1, email);

            // Execute the query and get the result set
            ResultSet resultSet = statement.executeQuery();

            // If the user exists, retrieve the password
            if (resultSet.next()) {
                password = resultSet.getString("password");
            }
        }
        return password;
    }

    public List<Appointment> getAppointmentsForAdmin() throws ClassNotFoundException, SQLException {
        List<Appointment> appointments = new ArrayList<>();

        String sql = "SELECT a.appointmentid, a.patientid, a.date, a.department, a.creation, a.description, a.doctorname, a.time_slot, "
                + "CONCAT(p.firstname, ' ', p.lastname) AS patient_name "
                + "FROM appointment a "
                + "JOIN patient p ON a.patientid = p.patiendid";

        try (Connection connection = new DatabaseConnection().getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Appointment appt = new Appointment();

                // Set appointment fields from the result set
                appt.setId(resultSet.getInt("appointmentid"));
                appt.setPatientId(resultSet.getInt("patientid"));
                appt.setAppointmentDate(resultSet.getDate("date").toString());
                appt.setDepartment(resultSet.getString("department"));
                appt.setCreationDate(resultSet.getTimestamp("creation").toString());
                appt.setDescription(resultSet.getString("description"));
                appt.setDoctorname(resultSet.getString("doctorname"));
                appt.setTime(resultSet.getString("time_slot"));

                // Set the patient full name from the result set (firstname + lastname)
                appt.setPatientname(resultSet.getString("patient_name"));

                appointments.add(appt);
            }
        }

        return appointments;
    }

    //
    public Employee getEmployeeById(int employeeId) {
        Employee employee = null;

        try (Connection conn = new DatabaseConnection().getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM employee WHERE employeeid = ?")) {

            stmt.setInt(1, employeeId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    employee = new Employee();
                    employee.setEmployeeid(rs.getInt("employeeid"));
                    employee.setName(rs.getString("name"));
                    employee.setEmail(rs.getString("email"));
                    employee.setRole(rs.getString("role"));
                    employee.setCreation(rs.getTimestamp("creation"));
                    // Add any other fields you need
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return employee;
    }

//retrive all meds
    public List<Sehlare> getAllMedications() throws SQLException, ClassNotFoundException {
        List<Sehlare> medications = new ArrayList<>();

        String query = "SELECT * FROM product";  // Adjust table name if needed

        try (Connection conn = new DatabaseConnection().getConnection();
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Sehlare product = new Sehlare();
                product.setId(rs.getInt("product_ID"));         // or your column name
                product.setName(rs.getString("name"));
                product.setType(rs.getString("type"));
                product.setQuantity(rs.getInt("quantity"));
                product.setCreation(rs.getTimestamp("creation"));   // Optional, if you have this

                medications.add(product);
            }
        }

        return medications;
    }

    public void deleteMedicationById(int id) throws SQLException, ClassNotFoundException {
        Connection conn = new DatabaseConnection().getConnection();
        String sql = "DELETE FROM product WHERE product_ID = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.executeUpdate();
        stmt.close();
        conn.close();
    }
    
    public void updateMedicationQuantity(int id, int quantity) throws SQLException, ClassNotFoundException {
    Connection conn = new DatabaseConnection().getConnection(); // however you get the DB connection
    String sql = "UPDATE product SET quantity = ? WHERE product_ID = ?";
    PreparedStatement stmt = conn.prepareStatement(sql);
    stmt.setInt(1, quantity);
    stmt.setInt(2, id);
    stmt.executeUpdate();
    conn.close();
}
    
    public List<Appointment> getAppointmentsByDoctor(String doctorName) throws ClassNotFoundException {
    List<Appointment> appointments = new ArrayList<>();
    
    String sql = "SELECT a.appointmentid, a.patientid, a.creation, a.date, a.department, a.description, " +
                 "a.status, a.doctorname, a.time_slot, CONCAT(p.firstname, ' ', p.lastname) AS patient_name " +
                 "FROM appointment a " +
                 "JOIN patient p ON a.patientid = p.patiendid " + // Assuming patientid is in the patient table
                 "WHERE a.doctorname = ?"; // Filtering by the doctor's name
    
    try (Connection conn = new DatabaseConnection().getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        
        ps.setString(1, doctorName);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            Appointment appt = new Appointment();
            appt.setId(rs.getInt("appointmentid"));
            appt.setPatientId(rs.getInt("patientid"));
            appt.setCreationDate(rs.getString("creation"));
            appt.setAppointmentDate(rs.getString("date"));
            appt.setDepartment(rs.getString("department"));
            appt.setDescription(rs.getString("description"));
            appt.setStatus(rs.getString("status"));
            appt.setDoctorname(rs.getString("doctorname"));
            appt.setTime(rs.getString("time_slot"));
            appt.setPatientname(rs.getString("patient_name")); // Set the concatenated patient name
            
            appointments.add(appt);
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
    
    return appointments;
}

    //Save prescription
    
    
    public boolean savePrescription(Prescription prescription) {
        boolean saved = false;
        String sql = "INSERT INTO prescriptions (appointment_id, doctor_name, patient_id, prescription_text) VALUES (?, ?, ?, ?)";

        try (Connection conn = new DatabaseConnection().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, prescription.getAppointmentId());
            stmt.setString(2, prescription.getDoctorName());
            stmt.setInt(3, prescription.getPatientId());
            stmt.setString(4, prescription.getPrescriptionText());

            int rows = stmt.executeUpdate();
            saved = rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return saved;
    }
    
    public Prescription getPrescriptionByAppointmentId(int appointmentId) {
    Prescription prescription = null;
    String sql = "SELECT * FROM Prescription WHERE appointmentId = ?";
    
    try (Connection conn = new DatabaseConnection().getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setInt(1, appointmentId);
        ResultSet rs = stmt.executeQuery();
        
        if (rs.next()) {
            prescription = new Prescription();
            prescription.setId(rs.getInt("id"));
            prescription.setAppointmentId(rs.getInt("appointmentId"));
            prescription.setPrescriptionText(rs.getString("prescription_text"));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    
    return prescription;
}

    
    //For stats , in the admin dashboard
            
    public static int getDoctorCount(Connection conn) {
        int count = 0;
        try {
            String sql = "SELECT COUNT(*) FROM employee WHERE role = 'doctor'";

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getPharmacyCount(Connection conn) {
        int count = 0;
        try {
            String sql = "SELECT COUNT(*) FROM employee where role = 'pharmacy'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public static int getPatientCount(Connection conn) {
        int count = 0;
        try {
            String sql = "SELECT COUNT(*) FROM patient";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }


    public ReportStats getReportStats() throws ClassNotFoundException, SQLException {
        ReportStats stats = new ReportStats();

  
        Connection conn = new DatabaseConnection().getConnection();

        Statement stmt = conn.createStatement();

        // Patients
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM patient");
        if (rs.next()) stats.setTotalPatients(rs.getInt(1));

        // Doctors
        rs = stmt.executeQuery("SELECT COUNT(*) FROM employee WHERE role='Doctor'");
        if (rs.next()) stats.setDoctorCount(rs.getInt(1));

        // Pharmacists
        rs = stmt.executeQuery("SELECT COUNT(*) FROM employee WHERE role='Pharmacy'");
        if (rs.next()) stats.setPharmacistCount(rs.getInt(1));

        // Booked Appointments
        rs = stmt.executeQuery("SELECT COUNT(*) FROM appointment");
        if (rs.next()) stats.setAppointmentsBooked(rs.getInt(1));

        // Upcoming
        rs = stmt.executeQuery("SELECT COUNT(*) FROM appointment WHERE status='To Be Attended'");
        if (rs.next()) stats.setAppointmentsCompleted(rs.getInt(1));

        // Declined
        rs = stmt.executeQuery("SELECT COUNT(*) FROM appointment WHERE status='Declined'");
        if (rs.next()) stats.setAppointmentsMissed(rs.getInt(1));
        
        // Approved
        rs = stmt.executeQuery("SELECT COUNT(*) FROM appointment WHERE status='Approved'");
        if (rs.next()) stats.setAppointmentsMissed(rs.getInt(1));

        conn.close();
        return stats;
    }
    
    public Patient getPatientById(int patiendid) throws SQLException, ClassNotFoundException {
    Patient patient = null;
    String query = "SELECT * FROM patient WHERE patiendid = ?";

   
    try (Connection conn = new DatabaseConnection().getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setInt(1, patiendid);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            patient = new Patient();
            patient.setPatientId(rs.getInt("patiendid"));
            patient.setFirstName(rs.getString("firstname"));
            patient.setLastName(rs.getString("lastname"));
            patient.setEmail(rs.getString("email"));
           // patient.setPassword(rs.getString("password"));
            patient.setGender(rs.getString("gender"));
            patient.setDob(rs.getString("dob"));
            patient.setAddress(rs.getString("address"));
           // patient.setPhoneNumber(rs.getString("phonenumber"));
           // patient.setCreationDate(rs.getTimestamp("creationdate"));
        }
    }
    return patient;
}
    public List<Appointment> getAppointmentsByDoctorName(String doctorName) throws SQLException {
    List<Appointment> appointments = new ArrayList<>();
    
    String query = "SELECT * FROM appointment WHERE doctorname = ?";
    try (Connection conn = new DatabaseConnection().getConnection();
         PreparedStatement pst = conn.prepareStatement(query)) {
        pst.setString(1, doctorName);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            Appointment appt = new Appointment();
            appt.setId(rs.getInt("id"));
            appt.setPatientname(rs.getString("patientname"));
            appt.setPatientId(rs.getInt("patientid"));
            appt.setDoctorname(rs.getString("doctorname"));
          
            appt.setStatus(rs.getString("status"));
            appt.setDescription(rs.getString("description"));
            appointments.add(appt);
        }
    }   catch (ClassNotFoundException ex) {
            Logger.getLogger(DatabaseManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    return appointments;
}
 
   
  public static List<Appointment> getAttendedAppointmentsByDoctor(String doctorName) {
    List<Appointment> appointments = new ArrayList<>();

    try {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/swpproject?useSSL=false","root", "system")) {
            String sql = "SELECT * FROM appointments WHERE doctor_name = ? AND status = 'attended'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, doctorName);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Appointment appt = new Appointment();
                appt.setId(rs.getInt("id"));
                appt.setPatientId(rs.getInt("patient_id"));
                appt.setPatientname(rs.getString("patient_name"));
                appt.setDoctorname(rs.getString("doctor_name"));
                appt.setAppointmentDate(rs.getString("appointment_date"));
                appt.setTime(rs.getString("time"));
                appt.setDescription(rs.getString("description"));
                appointments.add(appt);
            }
            
            rs.close();
            stmt.close();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return appointments;
}



    

    

}
