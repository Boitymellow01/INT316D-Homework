/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author TDK Nkadiey
 */
public class resetPasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve the values entered by the user in the form
        Integer employeeId = Integer.parseInt(request.getParameter("employeeid"));
        String email = request.getParameter("email");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        if (newPassword.equals(confirmPassword)) {
            try {
                boolean isResseted = new DatabaseManager().updatePassword(employeeId, email, newPassword);

                if (isResseted) {
                    RequestDispatcher disp = request.getRequestDispatcher("passwordUpdated.jsp");
                    disp.forward(request, response);

                } else {
            // Further clarrificication
            RequestDispatcher disp = request.getRequestDispatcher("notUpdatedPassword.jsp");
            disp.forward(request, response);

        }
            } catch (SQLException ex) {
                Logger.getLogger(resetPasswordServlet.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(resetPasswordServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            // Further clarrificication
            RequestDispatcher disp = request.getRequestDispatcher("notUpdatedPassword.jsp");
            disp.forward(request, response);

        }

    }

}
