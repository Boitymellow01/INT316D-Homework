/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Model.Appointment;
import Model.Doctor;
import Model.Employee;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher disp;

        // Retrieve form data
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        String employeePassword = null;
        //Doctor doc = new DatabaseManager().getDoctorByEmail(email);

       Employee doc = new DatabaseManager().getDoctorByEmail(email);
        //HttpSession session = request.getSession();
        //session.setAttribute("doctorname", doctorname);

        try {
            employeePassword = new DatabaseManager().logimDoctorMethod(email);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            int patientId = new DatabaseManager().getPatientIdByEmail(email);

            HttpSession session = request.getSession();
            session.setAttribute("patientId", patientId); // retrievedPatientId is from your database

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Ensure parameters are not null to prevent NullPointerException
        if (email == null || password == null) {
            response.sendRedirect("login.jsp");  // Redirect to login if parameters are missing
            return;
        }

        // Get the admin credentials from the context parameters
        String adminemail = getServletContext().getInitParameter("admin_email");
        String adminpassword = getServletContext().getInitParameter("admin_password");

        String patientpassword = null;
        try {
            patientpassword = new DatabaseManager().logimMethod(email);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Check if email and password match
        if (email.equals(adminemail) && password.equals(adminpassword)) {
            // Credentials match, forward to admin dashboard
            String role = "Admin";
            request.setAttribute("role", role); // Optional: Set role as a request attribute
            disp = request.getRequestDispatcher("admindashboard.jsp");
            disp.forward(request, response);
        } else if (password.equals(patientpassword)) {
            disp = request.getRequestDispatcher("patientdashboard.jsp");
            disp.forward(request, response);
        } else if (doc.getEmail().equals(email) && doc.getPassword().equalsIgnoreCase(password) && doc.getRole().equals("Doctor")) {
            String doctorname = doc.getName();
            HttpSession session = request.getSession();
            session.setAttribute("doctorname", doctorname);

            System.out.println(doctorname);
            List<Appointment> list;
            try {
                list = new DatabaseManager().getAppointmentsByDoctor(doctorname);

                request.setAttribute("appointments", list);
                disp = request.getRequestDispatcher("DoctorDashboard.jsp");
                disp.forward(request, response);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            // Credentials don't match, send back to login page with an error
            //request.setAttribute("errorMessage", "Invalid credentials");
            disp = request.getRequestDispatcher("LoginError.html");
            disp.forward(request, response);
        }
    }

}
