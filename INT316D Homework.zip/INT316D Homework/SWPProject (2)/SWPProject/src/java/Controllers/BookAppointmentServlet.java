/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author TDK Nkadiey
 */
public class BookAppointmentServlet extends HttpServlet {

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Retrieve form values
        String appointmentDate = request.getParameter("appointmentDate");
        String description = request.getParameter("notes");
        String department = request.getParameter("department");
        String status = "To Be Attended";
        String doctorName = "To Be Confirmed";
        String time = "To Be Confirmed";

        // 2. Retrieve patient ID from session
        HttpSession session = request.getSession();
        Integer patientId = (Integer) session.getAttribute("patientId");

        try {
            boolean success = new DatabaseManager().addAppointment(patientId, appointmentDate, department, description, status, doctorName,time);
            
             if (success) {
                // Redirect to view appointments page or confirmation
                 RequestDispatcher disp = request.getRequestDispatcher("successappointments.jsp");
                 disp.forward(request, response);
            } else {
                response.getWriter().println("Failed to book appointment. Please try again.");
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BookAppointmentServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BookAppointmentServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
