
package Controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String username = "root";
    private static final String password = "system";
    private static final String url = "jdbc:mysql://localhost:3306/swpproject?useSSL=false";

    public Connection getConnection() throws ClassNotFoundException, SQLException {
        // Ensure the JDBC driver is available
        Class.forName("com.mysql.cj.jdbc.Driver");
        // Establish connection
        Connection connection = DriverManager.getConnection(url, username, password);
        return connection;
    }
}
