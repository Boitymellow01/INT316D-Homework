package Controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieving form parameters
        Integer  patiendid = Integer.parseInt(request.getParameter("patiendid"));
        String firstName = request.getParameter("first_name");
        String lastName = request.getParameter("last_name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        String gender = request.getParameter("gender");
        String dob = request.getParameter("dob");
        String address = request.getParameter("address");

        // Create a DatabaseManager instance
        DatabaseManager dm = new DatabaseManager();

        try {
            // Attempt to register the patient
            //(int patiendid, String firstName, String lastName, String email, String password, String gender, String dob, String address, String phone)
            boolean isRegistered = dm.registerPatients(patiendid,firstName, lastName, email, password, gender , dob , address, phone);

            // If registration is successful
            if (isRegistered) {
                // Set success message and forward to success page
                request.setAttribute("message", "Registration successful!");
                RequestDispatcher dispatcher = request.getRequestDispatcher("/registrationSuccess.jsp");
                dispatcher.forward(request, response);
            } else {
                // If registration fails, set error message and forward to error page
                //request.setAttribute("error", "Registration failed. Please try again.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("registererror.html");
                dispatcher.forward(request, response);
            }
        } catch (ClassNotFoundException ex) {
            // Log the exception and show an error message to the user
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
            request.setAttribute("error", "There was an error with the database connection.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/registrationError.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException ex) {
            // Log the SQL exception and show an error message to the user
            Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
            request.setAttribute("error", "There was an error during the registration process.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/registrationError.jsp");
            dispatcher.forward(request, response);
        }
    }
}
