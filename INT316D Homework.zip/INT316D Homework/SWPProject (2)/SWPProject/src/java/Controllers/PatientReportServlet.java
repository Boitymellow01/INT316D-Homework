package Controllers;

import Model.Appointment;
import Model.Patient;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;


public class PatientReportServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

      try {
            HttpSession session = request.getSession();
            Integer patientId = (Integer) session.getAttribute("patientId");

            if (patientId == null) {
                response.sendRedirect("login.jsp");
                return;
            }

            DatabaseManager dbManager = new DatabaseManager();
            Patient pat = dbManager.getPatientById(patientId);
            List<Appointment> appointments = dbManager.getAppointmentsByPatientId(patientId);

            // Count appointment statuses
            int totalAppointments = appointments.size();
            int completedAppointments = (int) appointments.stream().filter(a -> "Completed".equalsIgnoreCase(a.getStatus())).count();
            int missedAppointments = (int) appointments.stream().filter(a -> "Missed".equalsIgnoreCase(a.getStatus())).count();

            // Find next appointment
            Appointment nextAppt = getNextAppointment(appointments);

            // Set attributes for the JSP
            request.setAttribute("patient", pat);
            request.setAttribute("appointments", appointments);
            request.setAttribute("totalAppointments", totalAppointments);
            request.setAttribute("completedAppointments", completedAppointments);
            request.setAttribute("missedAppointments", missedAppointments);
            request.setAttribute("nextAppointment", nextAppt);
            request.setAttribute("lastLogin", session.getAttribute("lastLogin"));

            // Forward to JSP
            RequestDispatcher dispatcher = request.getRequestDispatcher("patient_report.jsp");
            dispatcher.forward(request, response);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PatientReportServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while generating the report.");
        }
    }

    private Appointment getNextAppointment(List<Appointment> appointments) {
        java.time.LocalDate today = java.time.LocalDate.now();
        return appointments.stream()
                .filter(a -> {
                    try {
                        return java.time.LocalDate.parse(a.getAppointmentDate()).isAfter(today);
                    } catch (Exception e) {
                        return false;
                    }
                })
                .sorted((a1, a2) -> a1.getAppointmentDate().compareTo(a2.getAppointmentDate()))
                .findFirst().orElse(null);
    }
}


