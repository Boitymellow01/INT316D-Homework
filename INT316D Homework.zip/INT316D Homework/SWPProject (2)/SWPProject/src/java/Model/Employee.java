package Model;

import java.sql.Timestamp;

/**
 * Employee class that represents a general employee. A doctor is a specialized type of employee.
 */
public class Employee {

    private int employeeid;
    private String name;
    private String email;
    private String password;
    private Timestamp creation;
    private String role;
    private String department;

    public Employee(int employeeid, String name, String email, String password, Timestamp creation, String role, String department) {
        this.employeeid = employeeid;
        this.name = name;
        this.email = email;
        this.password = password;
        this.creation = creation;
        this.role = role;
        this.department = department;
    }

    public Employee() {
    }

    public int getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(int employeeid) {
        this.employeeid = employeeid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Timestamp getCreation() {
        return creation;
    }

    public void setCreation(Timestamp creation) {
        this.creation = creation;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    // Helper method to check if the employee is a doctor
    public boolean isDoctor() {
        return "doctor".equalsIgnoreCase(this.role);
    }
}
