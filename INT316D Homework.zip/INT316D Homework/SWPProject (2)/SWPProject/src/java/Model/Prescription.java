/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author TDK Nkadiey
 */
public class Prescription {
    private int id;
    private int appointmentId;
    private String doctorName;
    private int patientId;
    private String prescriptionText;

    // Constructors
    public Prescription() {}

    public Prescription(int appointmentId, String doctorName, int patientId, String prescriptionText) {
        this.appointmentId = appointmentId;
        this.doctorName = doctorName;
        this.patientId = patientId;
        this.prescriptionText = prescriptionText;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getAppointmentId() { return appointmentId; }
    public void setAppointmentId(int appointmentId) { this.appointmentId = appointmentId; }

    public String getDoctorName() { return doctorName; }
    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public String getPrescriptionText() { return prescriptionText; }
    public void setPrescriptionText(String prescriptionText) { this.prescriptionText = prescriptionText; }

}
