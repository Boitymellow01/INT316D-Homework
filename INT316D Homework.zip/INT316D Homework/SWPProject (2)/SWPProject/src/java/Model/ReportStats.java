/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author TDK Nkadiey
 */
public class ReportStats {
    

    private int totalPatients;
    private int doctorCount;
    private int pharmacistCount;
    private int appointmentsBooked;
    private int appointmentsCompleted;
    private int appointmentsMissed;

    // Getters and setters
    public int getTotalPatients() { return totalPatients; }
    public void setTotalPatients(int totalPatients) { this.totalPatients = totalPatients; }

    public int getDoctorCount() { return doctorCount; }
    public void setDoctorCount(int doctorCount) { this.doctorCount = doctorCount; }

    public int getPharmacistCount() { return pharmacistCount; }
    public void setPharmacistCount(int pharmacistCount) { this.pharmacistCount = pharmacistCount; }

    public int getAppointmentsBooked() { return appointmentsBooked; }
    public void setAppointmentsBooked(int appointmentsBooked) { this.appointmentsBooked = appointmentsBooked; }

    public int getAppointmentsCompleted() { return appointmentsCompleted; }
    public void setAppointmentsCompleted(int appointmentsCompleted) { this.appointmentsCompleted = appointmentsCompleted; }

    public int getAppointmentsMissed() { return appointmentsMissed; }
    public void setAppointmentsMissed(int appointmentsMissed) { this.appointmentsMissed = appointmentsMissed; }
}


